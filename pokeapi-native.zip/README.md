# native-pokeapi (Expo Go)

Versión móvil de la app de Pokémon (portada desde el proyecto web de React + Vite),
siguiendo la guía de clase. Pestañas: Lista, Informativa, Capturados, Favoritos, Usuario.
El detalle de cada Pokémon (`Pokemon`) se abre desde Lista, Capturados o Favoritos.

## Cómo usarlo en Codespaces

1. En GitHub crea un repositorio nuevo (botón verde **New**) y ábrelo en un **Codespace**.
2. En la terminal del Codespace crea el proyecto Expo (no olvides el punto):

   ```bash
   npm install -g expo-cli
   expo init .
   npx expo install @expo/metro-runtime
   ```

3. Instala las dependencias de navegación y almacenamiento:

   ```bash
   npx expo install @react-navigation/native @react-navigation/bottom-tabs @react-navigation/native-stack
   npx expo install react-native-screens react-native-safe-area-context react-native-gesture-handler react-native-reanimated
   npx expo install @react-native-async-storage/async-storage
   ```

4. Copia en la raíz del proyecto los archivos de este paquete:

   - `App.js` (reemplaza el que generó Expo)
   - la carpeta `src/` completa

5. Inicia la app y escanea el QR con **Expo Go** en tu celular:

   ```bash
   npx expo start --tunnel
   ```

Esta app no se ve en el navegador: se prueba directamente en el celular.

## Estructura

```
App.js
src/
  context/AppContext.js      favoritos compartidos + AsyncStorage
  componentes/
    lista.js                 lista, buscador y filtro por tipo
    filtro.js                botones de tipos
    pokemon.js               detalle + botón de favorito
    favoritos.js             lista de favoritos
    capturados.js            colección / álbum (4 nuevos)
    informativa.js           pestaña informativa (placeholder)
    usuario.js               pestaña usuario (placeholder)
```
